# Hybrid QAOA Routing v2.0.0

I am trying to make QAOA circuits cheaper to run by using the fact that ZZ gates inside a cost layer can be reordered. Rust builds the route; Qiskit compiles it into the target's native gates.

## Results

These are **local compilation** results on full 127-qubit FakeBrisbane, FakeKyiv, and FakeSherbrooke targets. The older 16–24q table below contains 348 paired cases from 116 different logical MaxCut circuits. Lower native 2Q count is better.

**32q extension:** on 120 fresh paired cases (40 different circuits), Hybrid completed 120/120 routes and used **7.2% fewer native 2Q gates** than Qiskit commuting + SAT. It won 105/120 target-specific cases, or 35/40 distinct circuits. In that original run with beam, mean compilation was 1.84 s versus 3.84 s. Medium50 also improved 2Q depth; dense75 depth was 0.3% worse. These are local fake-backend results, with symbolic route checks rather than a full 32q quantum simulation. [32q report](results/v2_32q_combined_20260928.md) · [frozen 16–24q baseline](results/v2_frozen_16_24_20260928.md).

**64q, two independent runs:** 120 paired target cases from 40 distinct MaxCut circuits. Hybrid finished every route and won **120/120** comparisons against the tested Qiskit commuting + SAT pipeline by native 2Q count: 1,020,345 versus 1,070,652 (**4.7% fewer**). Summed 2Q depth was 2.4% lower; mean compilation was 3.00 s versus 10.88 s. A separate paired test found that Rust's initial line-order search alone cut 2Q count by **4.3%** versus plain line order. SAT did not prove an optimal starting layout under its fixed limit, so this is a win against that time-limited pipeline. Symbolic routing and native-gate checks passed; full 64q quantum equivalence and real-QPU performance were not measured. [Research report](results/v2_64q_research_report_20260928.md) · [frozen source and first holdout](results/v2_frozen_64q_holdout_20260928.md).

Above 24q, a 120-case A/B found that beam never finished a route and did not change gate count or depth. Skipping it cut measured 32q compile time from 1.88 s to 0.82 s. Hybrid then passed 8/8 route and correctness checks at each of 40, 48, and 64q. [Scaling smoke report](results/v2_40_48_64_smoke_20260928.md).

The latest 24-qubit medium-density change was checked on **90 fresh paired cases**: 30 different circuits on three targets, in two runs with no algorithm changes between them. It finished 90/90 routes, versus 31/90 for the previous Hybrid. It used 90,249 native 2Q gates versus 98,265 for Qiskit commuting + SAT (**8.2% fewer**) and had 2.8% less summed 2Q depth. It won 69/90 cases by gate count, or 23/30 distinct circuits. Mean compile time was 1.33 s versus 3.05 s. The one-layer depth was 0.8% worse, so the depth gain does not hold in every regime. [Combined report](results/v2_medium24_combined_20260928.md) · [first run](results/v2_medium24_rescue_20260928.csv) · [confirmation](results/v2_medium24_confirm_20260928.csv).

| Logical qubits | Cases | Stock level 3 | Original Hybrid | Hybrid with dense completion | Qiskit commuting + SAT |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 16, holdout | 240 | 136,353 | 113,246 | **100,840** | 107,483 |
| 16, scaling set | 36 | 20,565 | 17,281 | **15,222** | 16,394 |
| 20 | 36 | 35,412 | 32,703 | 26,717 | **25,968** |
| 24 | 36 | 53,586 | 51,345 | **41,631** | 41,718 |

The dense route finished **174/174 dense cases**; the original finished 116/174. On those dense cases together, it used **1.8% fewer** native 2Q gates than the commuting baseline. The win is small, and the 20-qubit dense set is still 0.3% worse. The table above predates the 24-qubit medium change; its medium-density cases used the original search. The original search still handles 16- and 20-qubit medium graphs.

For dense cases, median compile time was 0.55 s vs 1.50 s for the commuting baseline at 16 qubits, 1.38 s vs 2.85 s at 20, and 1.59 s vs 3.11 s at 24. Those times came from separate runs on the same PC, so treat them as approximate. [Full report](results/v2_dense_rescue_348.md) · [every case](results/v2_dense_rescue_348.csv) · [correctness checks](results/v2_dense_rescue_348_checks.md).

## How it works

On dense graphs and medium graphs from 24 qubits upward, Rust builds a complete route along a connected line of physical qubits. It also spends 0.15 s looking for a better starting order on that line. The old beam search gets up to 1 s only at 16–24q; larger circuits use the complete line routes alone. Qiskit compiles the candidates. Dense graphs use the candidate with the fewest native 2Q gates. For medium graphs from 24 qubits upward, the choice also requires 2Q depth within 10% of the shallowest candidate. The 16–24q policy is frozen.

The commuting baseline is a separate pipeline built from Qiskit's `Commuting2qGateRouter`, a SAT starting layout, and native compilation. It is stronger than default Stock level 3 and is the main comparison here. Its SAT search has a time limit, so this is not a claim against every possible Qiskit setup.

The new optimized-line routes passed symbolic SWAP and gate checks in all 90 medium 24-qubit cases. Earlier checks also covered selected 16/20/24-qubit cases; two selected compiled 16-qubit circuits passed probability checks with errors below `1e-13`. The 24-qubit compiled outputs were not fully simulated. These results do not measure fidelity on a real QPU.

## Run

Use Python 3.12 and Rust. From PowerShell in this folder:

```powershell
py -3.12 -m venv .venv
.\build_rust.ps1
.\.venv\Scripts\python.exe .\research_dense_rescue.py --suite all --output-name v2_dense_rescue_my_run
.\.venv\Scripts\python.exe .\research_medium24_rescue.py --graph-start 99100 --count 5 --output-name v2_medium24_my_run
.\.venv\Scripts\python.exe .\research_32plus.py --smoke --graph-start 99800 --output-name v2_32q_smoke_my_run
.\.venv\Scripts\python.exe .\research_32plus.py --sizes 32 --graph-start 99900 --graphs 5 --output-name v2_32q_my_run
.\.venv\Scripts\python.exe .\research_32plus.py --smoke --sizes 40 --graph-start 100000 --output-name v2_40q_smoke_my_run
.\.venv\Scripts\python.exe .\research_large_smoke.py --size 64 --graph-start 100900 --graphs 2
```

The dense benchmark compares against paired CSVs already in `results/`; the medium and 32q benchmarks compile all methods on the same fresh circuits. Use unused graph IDs and a new output name for each run. `research_32plus.py` accepts `--sizes 40`, `48`, or `64`; use `research_large_smoke.py` before a larger test at a new size. The entry points are [`compile_hybrid_dense_v2`](hybrid_level3_v2.py) and [`compile_hybrid_level3_v2`](hybrid_level3_v2.py); the Rust search is in [`rust_core/src/lib.rs`](rust_core/src/lib.rs).
