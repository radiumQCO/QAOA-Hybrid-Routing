# 64q line-ordering ablation

Graph IDs 101100–101104. The two variants use identical circuits, physical lines, Qiskit seed, and native compiler. The optimized variant includes the 0.15-second ordering search in its time. Each variant builds exactly one line route; there is no tournament or beam. All recorded routes pass symbolic SWAP/gate replay, final-mapping, coupling, and target-native 2Q checks. No full statevector or QPU execution is used.

| Family | Cases | Plain 2Q | Optimized 2Q | Change | Plain depth | Optimized depth | W/T/L | Mean plain / optimized time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| All | 60 | 535968 | 512799 | -4.3% | 18228 | 16929 | 60/0/0 | 1.26 / 1.40 s |
| medium50 | 30 | 266763 | 252777 | -5.2% | 8874 | 8328 | 30/0/0 | 1.19 / 1.32 s |
| dense75 | 30 | 269205 | 260022 | -3.4% | 9354 | 8601 | 30/0/0 | 1.32 / 1.48 s |

Peak process RAM: 500 MiB.
