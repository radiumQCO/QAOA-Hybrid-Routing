# 64q follow-up commands — completed

The 64q holdout at graph IDs 100700–100704 was frozen first. Both commands below were then run without changing the router, graph generator, Qiskit seed, SAT limit, or benchmark rules. See the [combined research report](v2_64q_research_report_20260928.md) for results.

## 1. Independent confirmation

This repeated the exact 60-case holdout protocol on graph IDs 101000–101004: medium50 and dense75, one and two QAOA layers, FakeBrisbane, FakeKyiv, and FakeSherbrooke. It compared Hybrid with commuting + SAT and Stock Level 3, keeping the same 2-second SAT feasibility-check limit and 8 GiB RAM stop. [Result](v2_64q_independent_confirmation.md).

```powershell
cd C:\Users\radiu\Documents\qaoa_v2_rust_port
$env:PYTHONPATH=(Resolve-Path .\.venv\Lib\site-packages).Path
$env:PYTHONDONTWRITEBYTECODE='1'
& 'C:\Users\radiu\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' .\research_32plus.py --sizes 64 --families medium50,dense75 --backends fake_brisbane,fake_kyiv,fake_sherbrooke --layers 1,2 --graphs 5 --graph-start 101000 --rss-stop-gib 8 --output-name v2_64q_independent_confirmation
```

Compare the aggregate paired native 2Q counts, 2Q depth, compile time, completion, and wins/ties/losses with the frozen holdout. Count target-specific cases and distinct logical circuits separately. The SAT result is a feasible time-limited mapping, not a proven optimal mapping unless the report says so.

## 2. Line-ordering ablation

This isolated the Rust ordering search on different graph IDs, 101100–101104. Both variants used the same physical line and native compiler. The plain variant used logical order 0, 1, 2, …; the optimized variant spent up to 0.15 s choosing a new order. Each variant compiled exactly one route, so a candidate tournament cannot account for the difference. The ordering time was included in the optimized total. [Result](v2_64q_line_order_ablation_20260928.md).

```powershell
cd C:\Users\radiu\Documents\qaoa_v2_rust_port
$env:PYTHONPATH=(Resolve-Path .\.venv\Lib\site-packages).Path
$env:PYTHONDONTWRITEBYTECODE='1'
& 'C:\Users\radiu\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' .\research_line_order_ablation.py --graph-start 101100 --graphs 5 --rss-stop-gib 8 --output-name v2_64q_line_order_ablation_20260928
```

The ablation checks symbolic gate/SWAP replay, final mapping, coupling edges, and target-native 2Q support. Neither follow-up constructs a 64q statevector or runs a QPU.
