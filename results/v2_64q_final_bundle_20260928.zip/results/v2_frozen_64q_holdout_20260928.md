# Frozen 64q holdout baseline

Source, installed Rust extension, and the untouched 60-case holdout output are saved in [the archive](v2_frozen_64q_holdout_20260928.zip). The router was not changed during or after this holdout. The snapshot is a restore point; the confirmation and ablation are prepared separately and have not been run.

- 64 logical qubits, 60 paired target cases, 20 distinct logical circuits; graph IDs 100700–100704.
- Routing completion: 60/60. Symbolic route certificates: 120. Selected native-circuit final mappings: 60/60.
- Native 2Q: Hybrid 509,815; commuting + SAT 535,260; Stock level 3 763,185. Hybrid vs commuting: -4.8%, 60/0/0 wins/ties/losses.
- Summed 2Q depth: Hybrid 16,896; commuting 17,352 (-2.6%).
- Mean compilation: Hybrid 3.00 s; commuting 10.96 s. Peak process RAM: 946 MiB.
- SAT first-layer optimality proven: 0/60 under the fixed 2-second feasibility-check limit. This is a comparison with that time-limited specialized pipeline.
- Checks cover SWAP/gate-stream replay, final mapping, coupling validity and native 2Q support. They do not establish complete 64q compiled-output quantum equivalence or real-QPU fidelity.

Archive SHA-256: `65058f8e4dff8f0930dd941a8754874e382c01580db4dd03853ca4be9fe9993e`

## Archived file SHA-256

- `hybrid_level3.py`: `e1e39073647d504460b4ce022c420127a16720e07c3101763eaf195d826225af`
- `hybrid_level3_v2.py`: `8f421970182b9043c6162a839008d21a8bd417a4c1d9f7701ba6a713fbdf3eb8`
- `rust_router_core.py`: `a6eaf97feec4f627f372050cd3e71517fcc9cd72903151af7ab0e52b2b3a5282`
- `rust_core/src/lib.rs`: `8186e9a757c0f4df55b9c538ee466f3ec3d904262819acd05f52af0c47e8ed16`
- `rust_core/Cargo.toml`: `bca9e378175bcd571807227f36d74529b0aef60b8c6ccb4cb5fec69002ca76a1`
- `rust_core/Cargo.lock`: `9f7be1e06d67d2036c88696fd560895304a978d3ee869aa885235f0889cfc2d6`
- `rust_core/pyproject.toml`: `945be9d6f1a551b5f704d2e7c21cc51293fa13c9cecb53060faa8be69ba0d88d`
- `layout_seed.py`: `33b2cae3ba8bcd806da6736e13ff76254984365f1c8670bb121d795dec8f1ebc`
- `research_32plus.py`: `319d79bb16786d3534ef946d9d3283f6741f458a69e6bfc7c33d38360761bc11`
- `research_commuting_baseline.py`: `1b3d113ea9cdab2ee2ac69f5b317193c1457b8f9cf08fa484b59033fd2bd937a`
- `research_final_holdout.py`: `47798c6639e57d865c4b88167d2fce1bffd5a3f5022da500c90df4ecf7433f7c`
- `research_scaling.py`: `b6063bd1d764b12355813c316c7a77737f40ad9c4134ace4d09212e894e854c2`
- `research_no_reroute.py`: `e05e0ad5fbeb2e36cba856296d6e98599f9a1278cd25e75e430cd47146bd5515`
- `benchmark.py`: `3efd560a517c758652dbe197b4ad5f6d3e29f65a9ac529dad1e23536afeb7bcf`
- `requirements.txt`: `61362a67d0cc6417b026bc9124166fce0b0fed4003477b0f866cd6b4ec22f8aa`
- `build_rust.ps1`: `627fcf11d2f5255496634f6ca5a0ec7be11435e27fc24e731a16017b2824f657`
- `README.md`: `d94771361daf05aa91967cf8b604d5e70b6eae77946fed2945d30ae5e3ec2f0a`
- `results/v2_64q_fresh_holdout.csv`: `2dc331c474a7577d129f58e16362393169e7ed6d8cb28bc2478992dcb68d96e9`
- `results/v2_64q_fresh_holdout.md`: `a7826a0116c9a6be5e4df6ee7ade8a4947ebac781c10d8176aa1eb405dd005ab`
- `runtime/qaoa_v4_rust.cp312-win_amd64.pyd`: `cdd00b9cf84bf2be205b93c7b116f9192370449babe47a74e617ae3861fc6056`
