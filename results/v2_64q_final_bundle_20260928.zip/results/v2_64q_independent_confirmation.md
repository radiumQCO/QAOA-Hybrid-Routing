# 32q+ QAOA routing benchmark

Graph IDs 101000–101004; fresh MaxCut graph seeds, full IBM fake targets. This is local compilation, not execution on a QPU. No full statevector or MPS simulation is used.

Symbolic replay checks each Rust route's SWAPs, gate order, final mapping, and coupling edges. The selected route's mapping is also checked after native compilation. Every 2Q gate is checked against the target. This does not prove full compiled-output quantum equivalence.

| Size / graph | Cases | Hybrid routes | Stock 2Q | Hybrid 2Q | Commuting 2Q | Hybrid depth | Commuting depth | Hybrid vs commuting | W/T/L | Mean Hybrid / commuting time | Peak RAM |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 64q dense75 | 30 | 30 | 413967 | 260673 | 268515 | 8622 | 8670 | -2.9% | 30/0/0 | 3.21 / 12.46 s | 952 MiB |
| 64q medium50 | 30 | 30 | 349239 | 249857 | 266877 | 8322 | 8658 | -6.4% | 30/0/0 | 2.79 / 9.16 s | 901 MiB |

Recorded 60 paired cases. Symbolic route checks: 120 candidate routes; selected compiled mapping checks: 60/60. Target-native 2Q support checked for every recorded circuit.
SAT first-layer optimum proven in 0/60 recorded cases; other cases retain the best feasible mapping found under the fixed 2-second feasibility-check limit.
