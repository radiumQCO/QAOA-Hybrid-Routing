# Hybrid QAOA Routing v2.0.0

I am trying to make QAOA circuits cheaper to run by using the fact that ZZ gates inside a cost layer can be reordered. Rust builds the route; Qiskit compiles it into the target's native gates.

## Results

These are **local compilation** results on full 127-qubit FakeBrisbane, FakeKyiv, and FakeSherbrooke targets. The 348 paired cases contain 116 different logical MaxCut circuits, each run on all three targets. Lower native 2Q count is better.

The latest 24-qubit medium-density change was checked on **90 fresh paired cases**: 30 different circuits on three targets, in two runs with no algorithm changes between them. It finished 90/90 routes, versus 31/90 for the previous Hybrid. It used 90,249 native 2Q gates versus 98,265 for Qiskit commuting + SAT (**8.2% fewer**) and had 2.8% less summed 2Q depth. It won 69/90 cases by gate count, or 23/30 distinct circuits. Mean compile time was 1.33 s versus 3.05 s. The one-layer depth was 0.8% worse, so the depth gain does not hold in every regime. [Combined report](results/v2_medium24_combined_20260928.md) · [first run](results/v2_medium24_rescue_20260928.csv) · [confirmation](results/v2_medium24_confirm_20260928.csv).

| Logical qubits | Cases | Stock level 3 | Original Hybrid | Hybrid with dense completion | Qiskit commuting + SAT |
| ---: | ---: | ---: | ---: | ---: | ---: |
| 16, holdout | 240 | 136,353 | 113,246 | **100,840** | 107,483 |
| 16, scaling set | 36 | 20,565 | 17,281 | **15,222** | 16,394 |
| 20 | 36 | 35,412 | 32,703 | 26,717 | **25,968** |
| 24 | 36 | 53,586 | 51,345 | **41,631** | 41,718 |

The dense route finished **174/174 dense cases**; the original finished 116/174. On those dense cases together, it used **1.8% fewer** native 2Q gates than the commuting baseline. The win is small, and the 20-qubit dense set is still 0.3% worse. The table above predates the 24-qubit medium change; its medium-density cases used the original search. The original search still handles 16- and 20-qubit medium graphs.

For dense cases, median compile time was 0.55 s vs 1.50 s for the commuting baseline at 16 qubits, 1.38 s vs 2.85 s at 20, and 1.59 s vs 3.11 s at 24. Those times came from separate runs on the same PC, so treat them as approximate. [Full report](results/v2_dense_rescue_348.md) · [every case](results/v2_dense_rescue_348.csv) · [correctness checks](results/v2_dense_rescue_348_checks.md).

## How it works

On dense graphs and 24-qubit medium graphs, Rust builds a complete route along a connected line of physical qubits. It also spends 0.15 s looking for a better starting order on that line and gives the old beam search up to 1 s to find another candidate. Qiskit compiles the candidates. Dense graphs use the candidate with the fewest native 2Q gates. For 24-qubit medium graphs, the choice also requires 2Q depth within 10% of the shallowest candidate. The original search still handles smaller medium graphs.

The commuting baseline is a separate pipeline built from Qiskit's `Commuting2qGateRouter`, a SAT starting layout, and native compilation. It is stronger than default Stock level 3 and is the main comparison here. Its SAT search has a time limit, so this is not a claim against every possible Qiskit setup.

The new optimized-line routes passed symbolic SWAP and gate checks in all 90 medium 24-qubit cases. Earlier checks also covered selected 16/20/24-qubit cases; two selected compiled 16-qubit circuits passed probability checks with errors below `1e-13`. The 24-qubit compiled outputs were not fully simulated. These results do not measure fidelity on a real QPU.

## Run

Use Python 3.12 and Rust. From PowerShell in this folder:

```powershell
py -3.12 -m venv .venv
.\build_rust.ps1
.\.venv\Scripts\python.exe .\research_dense_rescue.py --suite all --output-name v2_dense_rescue_my_run
.\.venv\Scripts\python.exe .\research_medium24_rescue.py --graph-start 99100 --count 5 --output-name v2_medium24_my_run
```

The dense benchmark compares against paired CSVs already in `results/`; the medium benchmark compiles all four methods on the same fresh circuits. Use unused graph IDs and a new output name for each run. The entry points are [`compile_hybrid_dense_v2`](hybrid_level3_v2.py) and [`compile_hybrid_level3_v2`](hybrid_level3_v2.py); the Rust search is in [`rust_core/src/lib.rs`](rust_core/src/lib.rs).
